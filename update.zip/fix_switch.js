const fs = require('fs');
let content = fs.readFileSync('wasm/src/circuit/CircuitNode.cpp', 'utf-8');
content = content.replace('case NodeType::XNOR:     typeStr = "XNOR"; break;', 'case NodeType::XNOR:     typeStr = "XNOR"; break;\n        case NodeType::NAND:     typeStr = "NAND"; break;\n        case NodeType::NOR:      typeStr = "NOR"; break;');
fs.writeFileSync('wasm/src/circuit/CircuitNode.cpp', content);
