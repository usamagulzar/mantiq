const fs = require('fs');
let content = fs.readFileSync('wasm/src/circuit/CircuitBuilder.h', 'utf-8');

content = content.replace('static CircuitNodePtr convertToNAND(const CircuitNodePtr& node);\n    static CircuitNodePtr convertToNOR(const CircuitNodePtr& node);\n    static void cancelDoubleNot(CircuitNodePtr& node);', '');

content = content.replace('public:\n    static CircuitNodePtr fromPostfix', 'public:\n    static CircuitNodePtr convertToNAND(const CircuitNodePtr& node);\n    static CircuitNodePtr convertToNOR(const CircuitNodePtr& node);\n    static void cancelDoubleNot(CircuitNodePtr& node);\n    static CircuitNodePtr fromPostfix');

fs.writeFileSync('wasm/src/circuit/CircuitBuilder.h', content);
