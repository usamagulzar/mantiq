const fs = require('fs');
let js = fs.readFileSync('js/worker-bridge.js', 'utf-8');

// Find _applySnapshot
let newLogic = `
    Object.assign(_state, snap);
    
    // AST Prover hook
    if (snap.circuitJSON && window.mantiqImplementationMode === 3 && window.runASTProver) {
        try {
            let data = JSON.parse(snap.circuitJSON);
            
            // Run prover on orig and simp separately
            let maxFanIn = window.mantiqMaxFanIn || 4;
            let family = window.mantiqICFamily || 'TTL';
            
            let origResult = runASTProver(JSON.stringify(data.original), family, maxFanIn);
            let simpResult = runASTProver(JSON.stringify(data.simplified), family, maxFanIn);
            
            if (origResult) data.original = origResult.ast;
            if (simpResult) data.simplified = simpResult.ast;
            
            _state.circuitJSON = JSON.stringify(data);
            
            // Expose the IC breakdown globally so UI can show it
            window._mantiqICBreakdown = simpResult ? { cost: simpResult.cost, family: family } : null;
        } catch (e) {
            console.error('AST Prover failed:', e);
        }
    } else {
        window._mantiqICBreakdown = null; // Clear if not Minimal
    }
`;

js = js.replace(/Object\.assign\(_state, snap\);/, newLogic.trim());

// Intercept Logic
let interceptLogic = `
            case 'mantiq_setMaxFanIn': {
                window.mantiqMaxFanIn = (args && args[0]) || 4;
                const fanIn = (args && args[0]) || 0;
                _workerWriteCall('_setMaxFanInAndSnapshot', [fanIn]);
                return undefined;
            }

            case 'mantiq_setImplementation': {
                window.mantiqImplementationMode = (args && args[0]) || 0;
                const impl = (args && args[0]) || 0;
                // If 3, we still set C++ to 0 (default) so we have a clean AST to start from
                _workerWriteCall('_setImplementationAndSnapshot', [impl === 3 ? 0 : impl]);
                return undefined;
            }
`;
js = js.replace(/case 'mantiq_setMaxFanIn':[\s\S]*?return undefined;\s*\}\s*case 'mantiq_setImplementation':[\s\S]*?return undefined;\s*\}/, interceptLogic.trim());

fs.writeFileSync('js/worker-bridge.js', js);
console.log('Patched worker-bridge.js');
