const fs = require('fs');
let js = fs.readFileSync('js/app-core.js', 'utf-8');

// 1. Add IC Family event listener and toggling logic for settings dialog
const initDialogBlock = `
    // Toggle family dropdown visibility
    document.querySelectorAll('.impl-select').forEach(select => {
        select.addEventListener('change', (e) => {
            const familyGroup = document.getElementById('dialog-ic-family-group');
            if (familyGroup) {
                familyGroup.style.display = (e.target.value === '3') ? 'block' : 'none';
            }
        });
    });

    // Family change
    document.getElementById('dialog-family-select')?.addEventListener('change', (e) => {
        window.mantiqICFamily = e.target.value;
        if (window.mantiqImplementationMode === 3 && typeof wasmReady !== 'undefined' && wasmReady && typeof Module !== 'undefined') {
            // Trigger a re-eval by setting mode again
            Module.ccall('mantiq_setImplementation', null, ['number'], [3]);
        }
    });

    // Eye icon toggle logic
    let labelsVisible = true;
    document.querySelectorAll('.toggle-ic-labels-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            labelsVisible = !labelsVisible;
            document.body.classList.toggle('hide-ic-labels', !labelsVisible);
            btn.style.opacity = labelsVisible ? '1' : '0.5';
        });
    });
`;

js = js.replace(/\/\/ Bind setting changes/, initDialogBlock.trim() + '\n\n    // Bind setting changes');
fs.writeFileSync('js/app-core.js', js);
console.log('Patched app-core.js');
