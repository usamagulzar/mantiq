const fs = require('fs');
let content = fs.readFileSync('wasm/src/circuit/CircuitNode.cpp', 'utf-8');
content = content.replace('if (t == NodeType::XOR) return "XOR";\n    if (t == NodeType::XNOR) return "XNOR";', 'if (t == NodeType::XOR) return "XOR";\n    if (t == NodeType::XNOR) return "XNOR";\n    if (t == NodeType::NAND) return "NAND";\n    if (t == NodeType::NOR) return "NOR";');
fs.writeFileSync('wasm/src/circuit/CircuitNode.cpp', content);
