global.self = global;
const factory = require('./wasm/index.js');
factory().then(Module => {
    Module.ccall('mantiq_setExpression', null, ['string'], ['A & B & C & D']);
    Module.ccall('mantiq_setMaxFanIn', null, ['number'], [4]);
    console.log('FanIn 4:');
    console.log(Module.ccall('mantiq_getCircuitJSON', 'string', [], []));
    
    Module.ccall('mantiq_setMaxFanIn', null, ['number'], [2]);
    console.log('FanIn 2:');
    console.log(Module.ccall('mantiq_getCircuitJSON', 'string', [], []));
});
