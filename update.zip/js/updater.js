async function initializeCapacitorUpdater() {
    if (!window.Capacitor || !window.Capacitor.isNativePlatform()) return;

    // Auto-hide the install button if it's visible in native app
    const style = document.createElement('style');
    style.textContent = `
        #landing-install-app-btn, #pwa-install-btn { display: none !important; }
    `;
    document.head.appendChild(style);

    try {
        console.log('[Updater] Checking for remote updates...');
        const remoteSw = await fetch('https://mantiq.usamagulzar.dev/sw.js?t=' + Date.now()).then(r => r.text());
        
        // Extract CACHE_NAME
        const remoteVersionMatch = remoteSw.match(/const\s+CACHE_NAME\s*=\s*['"]([^'"]+)['"]/);
        if (!remoteVersionMatch) return;
        
        const remoteVersion = remoteVersionMatch[1];
        const localVersion = localStorage.getItem('mantiq_app_version') || 'mantiq-cache-v2.2.16'; // Fallback to current bundled one
        
        if (remoteVersion !== localVersion) {
            console.log(`[Updater] Update found! (Local: ${localVersion}, Remote: ${remoteVersion}). Downloading...`);
            
            // Extract urlsToCache
            const urlsMatch = remoteSw.match(/const\s+urlsToCache\s*=\s*\[([\s\S]*?)\];/);
            if (!urlsMatch) return;
            
            const rawUrls = urlsMatch[1].split('\n')
                .map(line => line.trim())
                .filter(line => line.startsWith("'") || line.startsWith('"'))
                .map(line => line.replace(/['",]/g, ''));
                
            // Open the cache of the NEW version, but because we are locally intercepted, 
            // the new cache will be ready to take over. But wait, `sw.js` locally 
            // only serves from its own hardcoded CACHE_NAME or ignores the remote cache.
            // Let's explicitly inject into the local cache name so it works immediately.
            const cache = await caches.open('mantiq-cache-v2.2.16');
            
            for (const url of rawUrls) {
                try {
                    const remoteUrl = 'https://mantiq.usamagulzar.dev/' + url.replace('./', '');
                    const response = await fetch(remoteUrl);
                    if (response.ok) {
                        // Store the response with the local relative URL request
                        // so the local service worker intercepts it properly
                        await cache.put(new Request(url), response);
                    }
                } catch (err) {
                    console.warn(`[Updater] Failed to cache ${url}:`, err);
                }
            }
            
            localStorage.setItem('mantiq_app_version', remoteVersion);
            console.log('[Updater] Update downloaded and cached successfully. It will be applied on the next launch.');
        } else {
            console.log('[Updater] App is up to date.');
        }
    } catch (e) {
        console.error('[Updater] Failed to check for updates', e);
    }
}

// Run the updater
window.addEventListener('load', () => {
    // Wait a bit for the app to initialize before checking for updates
    setTimeout(initializeCapacitorUpdater, 2000);
});

// Helper for native downloads
window.mantiqNativeDownload = async function(filename, data, isBase64) {
    if (!window.Capacitor || !window.Capacitor.isNativePlatform()) return false;
    
    try {
        const { Filesystem, Share } = window.Capacitor.Plugins;
        let fileData = data;
        
        if (isBase64 && data.includes(',')) {
            fileData = data.split(',')[1];
        } else if (!isBase64) {
            // Convert string to base64 for writing
            fileData = btoa(unescape(encodeURIComponent(data)));
        }

        const result = await Filesystem.writeFile({
            path: filename,
            data: fileData,
            directory: 'CACHE' // Use Cache dir for temporary file before sharing
        });

        await Share.share({
            title: filename,
            url: result.uri,
            dialogTitle: 'Save or Share'
        });
        
        return true;
    } catch (e) {
        console.error('Native download failed:', e);
        throw e;
    }
};
