/**
 * Mantiq HTML5 Bridge Controller & UI Synchronizer
 *
 * Architecture (non-blocking backend):
 *   The WASM engine runs entirely inside a Web Worker (wasm/mantiq-worker.js).
 *   Heavy computation (ASTProver, Quine-McCluskey) never touches the main thread.
 *
 *   Latest-wins protocol: every write (setExpression, setSOP, etc.) gets a
 *   monotonically-increasing sequence number (_latestSeq). The worker includes
 *   that number in its snapshot reply. The main thread only applies a snapshot
 *   when its seq === _latestSeq — all older, stale snapshots are silently dropped.
 *
 *   Computed fields (kmap, truth table, circuit, verilog) are cleared immediately
 *   when a new expression is sent so no stale data is ever shown while the worker
 *   is still computing.
 */

window.normalizeExprForCompare = function(s) {
    if (!s) return '';
    return String(s).replace(/\s+/g, '').toLowerCase();
};

// ── Web Worker bridge ─────────────────────────────────────────────────────────

/** Cached state — populated by the worker after every computation. */
const _state = {
    hasResult:        false,
    isAlwaysTrue:     false,
    isAlwaysFalse:    false,
    expression:       '',
    simplifiedExpr:   '',
    allSolutions:     '[]',
    qmSteps:          '',
    variables:        '[]',
    variableStates:   '{}',
    truthTableJSON:   '',
    kMapJSON:         '',
    circuitJSON:      '',
    verilogGate:          '',
    verilogDataflow:      '',
    addTestbenchGate:     true,
    addTestbenchDataflow: true,
    currentView:          0,
    // Which expression the CACHED computed fields (kMapJSON/truthTableJSON/...)
    // actually correspond to. Unlike _state.expression (which is updated the
    // instant setExpression is called, before the worker has done anything),
    // this only ever advances when a real snapshot comes back from the worker.
    // Views must check this before trusting the cache, or they'll render
    // stale data from a still-in-flight request.
    computedForExpr:      ''
};

/** Monotonically-increasing sequence counter for latest-wins. */
let _latestSeq = 0;

/** Pending promise map for request-response calls. */
const _pending = new Map();
let   _nextId  = 1;
let   _proofTimeout = null;

/**
 * Mirrors ExpressionProcessor::tryParseShorthand()'s regexes (kmapPattern,
 * shortPattern, shortPatternOnlyDC in ExpressionProcessor.cpp). Shorthand
 * input (m(...)/M(...)/KMAP(...)) is resolved entirely inside that function
 * and never reaches the ASTProver branch, so there is no algebraic-proof
 * narrative to produce for it — scheduling _runProofAndSnapshot for shorthand
 * would just recompute an identical snapshot.
 */
const _KMAP_CMD_RE          = /^\s*KMAP\s*\(([^)]+)\)\s*$/i;
const _SHORTHAND_RE         = /^\s*(?:[a-zA-Z0-9_,'\s\u2080-\u2089]+:)?\s*[mM]\s*\([\d,\s]*\)(?:\s*[dD]\s*\([\d,\s]*\))?\s*$/;
const _SHORTHAND_DC_ONLY_RE = /^\s*(?:[a-zA-Z0-9_,'\s\u2080-\u2089]+:)?\s*[dD]\s*\([\d,\s]*\)\s*$/;

function _isShorthandInput(expr) {
    return _KMAP_CMD_RE.test(expr) || _SHORTHAND_RE.test(expr) || _SHORTHAND_DC_ONLY_RE.test(expr);
}

/**
 * Mirrors the worker's VIEW_FIELDS map (mantiq-worker.js). Used to decide,
 * on a view switch, whether the field(s) that view needs were actually
 * included in the last snapshot — buildSnapshot() now only computes the
 * heavy fields for whichever view was active at the time of the write.
 */
const VIEW_FIELDS_JS = {
    0: ['circuitJSON', 'kMapJSON'],                     // SIMULATION
    1: ['circuitJSON', 'kMapJSON'],                     // CIRCUIT
    2: ['kMapJSON'],                                    // KMAP
    3: ['truthTableJSON', 'kMapJSON'],                  // TRUTHTABLE
    4: ['verilogGate', 'verilogDataflow', 'kMapJSON'],  // VERILOG
    5: ['kMapJSON']                                     // SOLUTION
};

/** Heavy fields known-fresh for the current expression/result. Reset on every content-changing snapshot. */
const _freshFields = new Set();

/** Spawn the worker that hosts the WASM engine. */
const _worker = new Worker('wasm/mantiq-worker.js?v=1.5.1');

_worker.onmessage = function (event) {
    const msg = event.data;

    // WASM initialised
    if (msg.type === 'ready') {
        wasmReady = true;
        if (window.onMantiqInit) window.onMantiqInit();
        return;
    }

    if (msg.type === 'state-snapshot') {
        if (msg.seq === _latestSeq) {
            _applySnapshot(msg.snapshot);
            if (window.requestAnimationFrame) {
                requestAnimationFrame(() => updateFrontend());
            } else {
                updateFrontend();
            }
        }
        return;
    }

    // Regular request-response
    if (msg.id !== undefined) {
        const { resolve, reject } = _pending.get(msg.id) || {};
        _pending.delete(msg.id);
        if (msg.error) {
            console.error('[Mantiq Worker Error]:', msg.error);
            if (reject) reject(new Error(msg.error));
        } else {
            if (resolve) resolve(msg.result);
        }
    }
};

_worker.onerror = function (e) {
    console.error('[Mantiq] Worker system error:', e);
};

let _textDecoder = null;

/** Apply a state snapshot from the worker to the local cache. */
function _applySnapshot(snap) {
    if (!snap) return;

    
    Object.assign(_state, snap);
    if (snap.expression !== undefined) _state.computedForExpr = snap.expression;
    // computedFields lists which heavy fields (truthTableJSON/kMapJSON/circuitJSON/
    // verilogGate/verilogDataflow) this snapshot actually refreshed. A field left out
    // of the snapshot keeps whatever was cached before — it belongs to a different
    // view and wasn't recomputed. resetFreshness distinguishes two cases: a real
    // content change (setExpression/setSOP/setSelectedSolution/runProof) means every
    // previously-cached heavy field is now suspect except the one(s) just rebuilt, so
    // the freshness set is dropped and replaced. A non-content-changing snapshot
    // (toggleVariable, or backfilling a view's field on switch) can't have made any
    // other view's cached field stale, so it only ADDS to what's already fresh.
    if (Array.isArray(snap.computedFields)) {
        if (snap.resetFreshness !== false) {
            _freshFields.clear();
        }
        snap.computedFields.forEach(f => _freshFields.add(f));
    }
    if (snap.variableStates) {
        try { simInputStates = JSON.parse(snap.variableStates); } catch (_) {}
    }
}

/**
 * Clear all computed/derived fields immediately so stale values from the
 * previous expression are never shown while the worker is computing.
 */
function _clearComputedState() {
    _state.hasResult       = false;
    _state.isAlwaysTrue    = false;
    _state.isAlwaysFalse   = false;
    _state.simplifiedExpr  = '';
    _state.allSolutions    = '[]';
    _state.qmSteps         = '';
    _state.variables       = '[]';
    _state.variableStates  = '{}';
    _state.truthTableJSON  = '';
    _state.kMapJSON        = '';
    _state.circuitJSON     = '';
    _state.verilogGate     = '';
    _state.verilogDataflow = '';
}

/**
 * Fire an aggregate call to the worker.
 * Increments _latestSeq so any in-flight older computation is ignored when it
 * eventually replies. The seq is passed to the worker so it can also skip
 * building the snapshot if a newer request already arrived.
 */
function _workerWriteCall(fn, args, view, onDone) {
    const seq = ++_latestSeq;
    const id  = _nextId++;
    _pending.set(id, {
        resolve: () => { if (onDone) onDone(); },
        reject:  () => { if (onDone) onDone(); }
    });
    // buildSnapshot() in the worker only marshals the heavy field(s) that `view`
    // needs (defaults to whatever view is currently on screen) — no point paying
    // for KMap/TruthTable/Circuit/Verilog JSON on every keystroke if none of
    // those views are visible.
    _worker.postMessage({ id, fn, args: args || [], seq, view: view !== undefined ? view : _state.currentView, addTestbenchGate: _state.addTestbenchGate, addTestbenchDataflow: _state.addTestbenchDataflow });
}

/**
 * Coalesced dispatch for _setExpressionAndSnapshot: guarantees at most one
 * is ever in flight in the worker. The worker processes messages strictly
 * in order and each _setExpressionAndSnapshot re-runs full Quine-McCluskey
 * synchronously — so firing one on every keystroke/click (e.g. for the live
 * KMap/Truth Table views) can queue up a backlog of already-obsolete
 * recomputes that the worker has to fully grind through before it even
 * starts on the latest one, making the view look stuck.
 *
 * Extra requests that arrive while one is running don't queue up — they
 * just mark that one more pass is needed, using whatever _state.expression
 * is by the time the in-flight one completes.
 */
let _exprComputeInFlight = false;
let _exprComputeQueued   = false;

function _onExprComputeDone() {
    _exprComputeInFlight = false;
    if (_exprComputeQueued) {
        _exprComputeQueued = false;
        _dispatchExprComputeNow();
    }
}

function _dispatchExprComputeNow() {
    _exprComputeInFlight = true;
    _workerWriteCall('_setExpressionAndSnapshot', [_state.expression], undefined, _onExprComputeDone);
}

function _requestExprCompute() {
    if (_exprComputeInFlight) {
        _exprComputeQueued = true;
    } else {
        _dispatchExprComputeNow();
    }
}

/** Fire a regular (non-snapshot) call to the worker. */
function _workerCall(fn, args) {
    return new Promise((resolve, reject) => {
        const id = _nextId++;
        _pending.set(id, { resolve, reject });
        _worker.postMessage({ id, fn, args: args || [] });
    });
}

/**
 * Drop-in replacement for Module.ccall() — reads synchronously from cache.
 * Write operations are forwarded to the worker asynchronously (latest-wins).
 */
const Module = {
    ccall(fn, returnType, argTypes, args) {
        switch (fn) {
            // ── Reads (instant from cache) ──────────────────────────────────
            case 'mantiq_hasResult':     return _state.hasResult     ? 1 : 0;
            case 'mantiq_isAlwaysTrue':  return _state.isAlwaysTrue  ? 1 : 0;
            case 'mantiq_isAlwaysFalse': return _state.isAlwaysFalse ? 1 : 0;
            case 'mantiq_getView':       return _state.currentView;
            case 'mantiq_isSyntaxValid': return 1;

            case 'mantiq_getExpression':     return _state.expression     || 0;
            case 'mantiq_getSimplifiedExpr': return _state.simplifiedExpr || 0;
            case 'mantiq_getAllSolutions':    return _state.allSolutions   || 0;
            case 'mantiq_getQMSteps':        return _state.qmSteps        || 0;
            case 'mantiq_getVariables':      return _state.variables       || 0;
            case 'mantiq_getVariableStates': return _state.variableStates  || 0;
            case 'mantiq_getTruthTableJSON': return _state.truthTableJSON  || 0;
            case 'mantiq_getKMapJSON':       return _state.kMapJSON        || 0;
            case 'mantiq_getCircuitJSON':    return _state.circuitJSON     || 0;
            case 'mantiq_getVerilogCode':    return (args && args[0]) ? _state.verilogGate : _state.verilogDataflow;

            // ── Writes (async, latest-wins) ─────────────────────────────────
            case 'mantiq_setExpression': {
                const expr = (args && args[0]) || '';
                const exprChanged = _state.expression !== expr;
                _state.expression = expr;
                if (expr.trim() === '') {
                    _clearComputedState();
                    _state.currentView = 0;
                } else if (exprChanged) {
                    // if expression changes: keep cache of only the current section selected, and delete for others
                    const keepFields = VIEW_FIELDS_JS[_state.currentView] || [];
                    const allFields = ['truthTableJSON', 'kMapJSON', 'circuitJSON', 'verilogGate', 'verilogDataflow'];
                    allFields.forEach(f => {
                        if (!keepFields.includes(f)) {
                            _state[f] = '';
                            _freshFields.delete(f);
                        }
                    });
                }
                if (typeof _exprDebounceTimeout !== 'undefined' && _exprDebounceTimeout) clearTimeout(_exprDebounceTimeout);
                // KMap (2) and Truth Table (3) views need to reflect every keystroke
                // immediately — debouncing them makes the grid feel laggy/stale while
                // typing. Skip the debounce delay for those views only.
                const _isLiveGridView = (_state.currentView === 2 || _state.currentView === 3);
                const _runExpressionUpdate = () => {
                    _workerWriteCall('_setExpressionAndSnapshot', [expr]);
                    if (_proofTimeout) clearTimeout(_proofTimeout);
                    if (expr.trim() !== '' && !_isShorthandInput(expr)) {
                        window._proofStartTime = Date.now();
                        _proofTimeout = setTimeout(() => {
                            _workerWriteCall('_runProofAndSnapshot', []);
                        }, 300);
                    }
                };
                if (_isLiveGridView) {
                    if (_proofTimeout) clearTimeout(_proofTimeout);
                    if (expr.trim() !== '' && !_isShorthandInput(expr)) {
                        window._proofStartTime = Date.now();
                        _proofTimeout = setTimeout(() => {
                            _workerWriteCall('_runProofAndSnapshot', []);
                        }, 300);
                    }
                    _requestExprCompute();
                } else {
                    _exprDebounceTimeout = setTimeout(_runExpressionUpdate, 60);
                }
                return undefined;
            }

            case 'mantiq_setSOP': {
                const sop = (args && args[0]) ? 1 : 0;
                _workerWriteCall('_setSopAndSnapshot', [sop]);
                if (_proofTimeout) clearTimeout(_proofTimeout);
                if (_state.expression.trim() !== '' && !_isShorthandInput(_state.expression)) {
                    window._proofStartTime = Date.now();
                    _proofTimeout = setTimeout(() => {
                        _workerWriteCall('_runProofAndSnapshot', []);
                    }, 400);
                }
                return undefined;
            }

            case 'mantiq_setMaxFanIn': {
                const fanIn = (args && args[0]) || 0;
                _workerWriteCall('_setMaxFanInAndSnapshot', [fanIn]);
                return undefined;
            }

            case 'mantiq_setView': {
                const view = (args && args[0]) || 0;
                _state.currentView = view;
                _workerCall(fn, args);
                // The last snapshot only computed heavy fields for whichever view was
                // active at the time. If we're switching to a view whose field(s)
                // weren't included, backfill with a cheap single-purpose fetch — this
                // just re-serializes the already-processed result, no QM recompute.
                const needed = VIEW_FIELDS_JS[view] || [];
                if (_state.hasResult && needed.some(f => !_freshFields.has(f))) {
                    _workerWriteCall('_refreshViewFields', [], view);
                }
                return undefined;
            }

            case 'mantiq_setSelectedSolution': {
                const idx = (args && args[0]) || 0;
                _workerWriteCall('_setSelectedSolutionAndSnapshot', [idx]);
                if (_proofTimeout) clearTimeout(_proofTimeout);
                if (_state.expression.trim() !== '' && !_isShorthandInput(_state.expression)) {
                    window._proofStartTime = Date.now();
                    _proofTimeout = setTimeout(() => {
                        _workerWriteCall('_runProofAndSnapshot', []);
                    }, 400);
                }
                return undefined;
            }

            case 'mantiq_setCustomSimplifiedExpr': {
                const expr = (args && args[0]) || '';
                _workerWriteCall('_setCustomSimplifiedExprAndSnapshot', [expr]);
                return undefined;
            }

            case 'mantiq_freeStr':
                return undefined; // No-op — strings come from JS cache

            default:
                _workerCall(fn, args);
                return undefined;
        }
    },
    UTF8ToString(val) {
        return (typeof val === 'string') ? val : '';
    }
};


// ── Global state ─────────────────────────────────────────────────────────────
let wasmReady = false;
let lastSimplifiedExpr = '';
let lastActiveView = -1;
let kmapViewMode = 'normal';
let simInputStates = {};
let panelsState = {
    orig: { x: 0, y: 0, scale: 1.0, fitScale: 1.0 },
    simp: { x: 0, y: 0, scale: 1.0, fitScale: 1.0 },
    simOrig: { x: 0, y: 0, scale: 1.0, fitScale: 1.0 },
    simSimp: { x: 0, y: 0, scale: 1.0, fitScale: 1.0 }
};
