const fs = require('fs');
let content = fs.readFileSync('wasm/src/circuit/CircuitBuilder.cpp', 'utf-8');

// The functions were appended at the end of the file, let's remove them and insert them properly INSIDE the namespace.
// The namespace closes with } // namespace com::mantiq::circuit

let idx = content.indexOf('CircuitNodePtr CircuitBuilder::convertToNAND');
if (idx !== -1) {
    content = content.substring(0, idx);
}

const funcs = 
CircuitNodePtr CircuitBuilder::convertToNAND(const CircuitNodePtr& node) {
    if (!node) return nullptr;
    if (node->isVariable()) return cloneNode(node);

    std::vector<CircuitNodePtr> children;
    for (const auto& c : node->getChildren()) {
        children.push_back(convertToNAND(c));
    }

    auto makeNand = [](const std::vector<CircuitNodePtr>& ch) {
        auto n = std::make_shared<CircuitNode>(NodeType::NAND);
        for (const auto& c : ch) n->addChild(c);
        return n;
    };

    if (node->getType() == NodeType::NOT) {
        return makeNand(children);
    } else if (node->getType() == NodeType::AND) {
        return makeNand({ makeNand(children) });
    } else if (node->getType() == NodeType::OR) {
        std::vector<CircuitNodePtr> negatedChildren;
        for (const auto& c : children) negatedChildren.push_back(makeNand({c}));
        return makeNand(negatedChildren);
    }
    return makeNand(children);
}

CircuitNodePtr CircuitBuilder::convertToNOR(const CircuitNodePtr& node) {
    if (!node) return nullptr;
    if (node->isVariable()) return cloneNode(node);

    std::vector<CircuitNodePtr> children;
    for (const auto& c : node->getChildren()) {
        children.push_back(convertToNOR(c));
    }

    auto makeNor = [](const std::vector<CircuitNodePtr>& ch) {
        auto n = std::make_shared<CircuitNode>(NodeType::NOR);
        for (const auto& c : ch) n->addChild(c);
        return n;
    };

    if (node->getType() == NodeType::NOT) {
        return makeNor(children);
    } else if (node->getType() == NodeType::OR) {
        return makeNor({ makeNor(children) });
    } else if (node->getType() == NodeType::AND) {
        std::vector<CircuitNodePtr> negatedChildren;
        for (const auto& c : children) negatedChildren.push_back(makeNor({c}));
        return makeNor(negatedChildren);
    }
    return makeNor(children);
}

void CircuitBuilder::cancelDoubleNot(CircuitNodePtr& node) {
    if (!node) return;

    auto isNotEquivalent = [](const CircuitNodePtr& n) {
        return n && (n->getType() == NodeType::NOT ||
                     ((n->getType() == NodeType::NAND || n->getType() == NodeType::NOR) && n->getChildren().size() == 1));
    };

    while (isNotEquivalent(node)) {
        CircuitNodePtr child1 = node->getChildren()[0];
        if (isNotEquivalent(child1)) {
            node = child1->getChildren()[0];
        } else {
            break;
        }
    }

    if (node && !node->isVariable()) {
        std::vector<CircuitNodePtr> newChildren;
        for (auto child : node->getChildren()) {
            CircuitNodePtr modChild = child;
            cancelDoubleNot(modChild);
            newChildren.push_back(modChild);
        }
        node->clearChildren();
        for (const auto& child : newChildren) {
            node->addChild(child);
        }
    }
}
;

// Insert before } // namespace com::mantiq::circuit
content = content.replace('} // namespace com::mantiq::circuit', funcs + '\n} // namespace com::mantiq::circuit');
fs.writeFileSync('wasm/src/circuit/CircuitBuilder.cpp', content);
