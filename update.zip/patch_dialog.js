const fs = require('fs');

// 1. Fix app.html
let html = fs.readFileSync('app.html', 'utf-8');

// Replace custom modal HTML with standard modal HTML
const newDialog = `
<!-- Circuit Settings Dialog -->
<div id="circuit-settings-dialog" class="modal-overlay" style="display: none;">
  <div class="modal sm">
    <div class="modal-header">
      <div class="modal-header-info">
        <div class="modal-header-icon">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
        </div>
        <h3>Circuit Settings</h3>
      </div>
      <button class="modal-close" id="circuit-settings-close" aria-label="Close">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
      </button>
    </div>
    <div class="modal-body" style="display:flex; flex-direction:column; gap:16px;">
      <div class="input-group">
        <label style="font-size: 13px; font-weight: 500; color: var(--text-secondary); margin-bottom: 6px; display: block;">Gate Implementation</label>
        <select class="impl-select" id="dialog-impl-select" style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid var(--border-color); background: var(--input-bg); color: var(--text-primary); outline: none; cursor: pointer;">
          <option value="0" selected>Default (AND / OR / NOT)</option>
          <option value="1">NAND-NAND</option>
          <option value="2">NOR-NOR</option>
        </select>
      </div>
      <div class="input-group">
        <label style="font-size: 13px; font-weight: 500; color: var(--text-secondary); margin-bottom: 6px; display: block;">Max Fan-In</label>
        <select class="fanin-select" id="dialog-fanin-select" style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid var(--border-color); background: var(--input-bg); color: var(--text-primary); outline: none; cursor: pointer;">
          <option value="2">2 Inputs</option>
          <option value="3">3 Inputs</option>
          <option value="4" selected>4 Inputs</option>
        </select>
      </div>
    </div>
  </div>
</div>
`;

html = html.replace(/<!-- Circuit Settings Dialog -->[\s\S]*?<\/div>\s*<\/div>\s*<\/div>/, newDialog.trim());

// We can remove the custom CSS block entirely and keep .circuit-settings-btn as an inline style for now or just append it nicely. 
// Actually I'll just remove the whole style block and put back the button style.
html = html.replace(/<style id="circuit-settings-styles">[\s\S]*?<\/style>/, `
<style id="circuit-settings-styles">
.circuit-settings-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  border: 1px solid var(--border-color, rgba(255,255,255,0.12));
  border-radius: 6px;
  padding: 4px 6px;
  cursor: pointer;
  color: var(--text-secondary, #aaa);
  transition: background 0.15s, color 0.15s;
  -webkit-tap-highlight-color: transparent;
  user-select: none;
}
.circuit-settings-btn:hover {
  background: var(--glass-bg, rgba(255,255,255,0.06));
  color: var(--text-primary, #fff);
}
</style>
`.trim());
fs.writeFileSync('app.html', html);


// 2. Fix app-core.js
let js = fs.readFileSync('js/app-core.js', 'utf-8');
// Remove the top level fanin-select loop
js = js.replace(/document\.querySelectorAll\('\.fanin-select'\)\.forEach\(select => \{[\s\S]*?\}\);\s*/g, '');
// Remove the top level impl-select loop
js = js.replace(/document\.querySelectorAll\('\.impl-select'\)\.forEach\(select => \{[\s\S]*?\}\);\s*/g, '');

// Replace the DOMContentLoaded block
const newBlock = `
// ── Circuit Settings Dialog ──────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    const overlay = document.getElementById('circuit-settings-dialog');
    if (!overlay) return;

    function openDialog() {
        overlay.style.display = 'flex';
        overlay.classList.add('active');
        setTimeout(() => overlay.style.opacity = '1', 10);
    }
    
    function closeDialog() {
        overlay.style.opacity = '0';
        setTimeout(() => {
            overlay.classList.remove('active');
            overlay.style.display = 'none';
        }, 200);
    }

    // Gear buttons on all 4 panels open the shared dialog
    ['btn-settings-orig', 'btn-settings-simp', 'btn-settings-sim-orig', 'btn-settings-sim-simp'].forEach(id => {
        const btn = document.getElementById(id);
        if (btn) btn.addEventListener('click', openDialog);
    });

    // Close via X button or clicking the backdrop
    const closeBtn = document.getElementById('circuit-settings-close');
    if (closeBtn) closeBtn.addEventListener('click', closeDialog);
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) closeDialog();
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && overlay.style.display !== 'none') closeDialog();
    });

    // Bind setting changes
    document.querySelectorAll('.impl-select').forEach(select => {
        select.addEventListener('change', (e) => {
            const impl = parseInt(e.target.value, 10);
            document.querySelectorAll('.impl-select').forEach(s => {
                if (s !== e.target) s.value = e.target.value;
            });
            if (typeof wasmReady !== 'undefined' && wasmReady && typeof Module !== 'undefined') {
                Module.ccall('mantiq_setImplementation', null, ['number'], [impl]);
            }
        });
    });

    document.querySelectorAll('.fanin-select').forEach(select => {
        select.addEventListener('change', (e) => {
            const fanIn = parseInt(e.target.value, 10);
            document.querySelectorAll('.fanin-select').forEach(s => {
                if (s !== e.target) s.value = e.target.value;
            });
            if (typeof wasmReady !== 'undefined' && wasmReady && typeof Module !== 'undefined') {
                Module.ccall('mantiq_setMaxFanIn', null, ['number'], [fanIn]);
            }
        });
    });
});
`;

js = js.replace(/\/\/ ── Circuit Settings Dialog ──────────────────────────────────────────────────[\s\S]*?\}\);\s*$/, newBlock.trim() + '\n');
fs.writeFileSync('js/app-core.js', js);
console.log('Fixed dialog UI and event bindings');
