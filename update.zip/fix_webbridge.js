const fs = require('fs');
let content = fs.readFileSync('wasm/src/WebBridge_web.cpp', 'utf-8');
content = content.replace('EMSCRIPTEN_KEEPALIVE void mantiq_setMaxFanIn(int fanIn) {\n    g_state.setMaxFanIn(fanIn);\n    g_state.setHasProcessed(false);\n}', 'EMSCRIPTEN_KEEPALIVE void mantiq_setMaxFanIn(int fanIn) {\n    g_state.setMaxFanIn(fanIn);\n    g_state.setHasProcessed(false);\n}\n\nEMSCRIPTEN_KEEPALIVE void mantiq_setImplementation(int mode) {\n    g_state.setImplementationMode(mode);\n    g_state.setHasProcessed(false);\n}');
fs.writeFileSync('wasm/src/WebBridge_web.cpp', content);
