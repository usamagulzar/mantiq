const fs = require('fs');
let lines = fs.readFileSync('js/app-core.js', 'utf-8').split('\n');
// find the first console.error('Failed to export K-Map:', err);
let idx = lines.findIndex(l => l.includes("console.error('Failed to export K-Map:', err);"));
console.log('Found at line', idx);

// find the second document.querySelectorAll('.impl-select').forEach
let endIdx = lines.findIndex((l, i) => i > idx && l.includes("document.querySelectorAll('.impl-select').forEach"));
console.log('End idx at', endIdx);

let newLines = lines.slice(0, idx + 1);
newLines.push("            showToast('Failed to export K-Map', 'error');");
newLines.push("        } finally {");
newLines.push("            finishExport();");
newLines.push("        }");
newLines.push("    });");
newLines.push("}");
newLines.push("");
newLines = newLines.concat(lines.slice(endIdx));

fs.writeFileSync('js/app-core.js', newLines.join('\n'));
console.log('Fixed');
