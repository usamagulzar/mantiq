const fs = require('fs');
let content = fs.readFileSync('wasm/src/circuit/CircuitBuilder.h', 'utf-8');
content = content.replace('static void enforceMaxFanIn(const CircuitNodePtr& node, int maxFanIn);', 'static void enforceMaxFanIn(const CircuitNodePtr& node, int maxFanIn);\n    static CircuitNodePtr convertToNAND(const CircuitNodePtr& node);\n    static CircuitNodePtr convertToNOR(const CircuitNodePtr& node);\n    static void cancelDoubleNot(CircuitNodePtr& node);');
fs.writeFileSync('wasm/src/circuit/CircuitBuilder.h', content);
