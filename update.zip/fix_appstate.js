const fs = require('fs');
let content = fs.readFileSync('wasm/src/app/AppState.h', 'utf-8');
content = content.replace('int maxFanIn = 4;', 'int maxFanIn = 4;\n    int implementationMode = 0; // 0=Default, 1=NAND, 2=NOR');
content = content.replace('void setMaxFanIn(int fanIn) { maxFanIn = fanIn; clearCircuits(); }', 'void setMaxFanIn(int fanIn) { maxFanIn = fanIn; clearCircuits(); }\n    void setImplementationMode(int mode) { implementationMode = mode; clearCircuits(); }\n    int getImplementationMode() const { return implementationMode; }');
fs.writeFileSync('wasm/src/app/AppState.h', content);
