#include "CircuitBuilder.h"
#include <algorithm>
#include <cctype>

namespace com::mantiq::circuit {

CircuitNodePtr CircuitBuilder::fromPostfix(const std::vector<std::string>& postfix, int maxFanIn) {
    if (postfix.empty()) {
        return nullptr;
    }

    std::vector<CircuitNodePtr> stack;

    for (const auto& token : postfix) {
        if (isVariable(token)) {
            stack.push_back(std::make_shared<CircuitNode>(token));
        } else if (isNot(token)) {
            if (stack.empty())
                return nullptr;
            CircuitNodePtr notGate = std::make_shared<CircuitNode>(NodeType::NOT);
            notGate->addChild(stack.back());
            stack.pop_back();
            stack.push_back(notGate);
        } else if (isBinaryOperator(token)) {
            if (stack.size() < 2)
                return nullptr;

            CircuitNodePtr right = stack.back(); stack.pop_back();
            CircuitNodePtr left = stack.back(); stack.pop_back();

            CircuitNodePtr gate = createGateForOperator(token, left, right);
            if (gate != nullptr) {
                stack.push_back(gate);
            }
        }
    }

    if (!stack.empty()) {
        collapseIdenticalGates(stack.back(), maxFanIn);
        if (maxFanIn > 1) enforceMaxFanIn(stack.back(), maxFanIn);
        return stack.back();
    }
    return nullptr;
}

CircuitNodePtr CircuitBuilder::fromSimplifiedTerms(const std::vector<std::string>& terms, const std::vector<std::string>& variables, bool isPOS, int maxFanIn) {
    if (terms.empty()) {
        return nullptr;
    }

    std::vector<CircuitNodePtr> termNodes;
    for (const auto& binary : terms) {
        CircuitNodePtr termNode = buildTermNode(binary, variables, isPOS);
        if (termNode != nullptr) {
            termNodes.push_back(termNode);
        }
    }

    if (termNodes.empty()) {
        return nullptr;
    }

    if (termNodes.size() == 1) {
        collapseIdenticalGates(termNodes[0], maxFanIn);
        if (maxFanIn > 1) enforceMaxFanIn(termNodes[0], maxFanIn);
        return termNodes[0];
    }

    NodeType rootType = isPOS ? NodeType::AND : NodeType::OR;
    CircuitNodePtr root = std::make_shared<CircuitNode>(rootType);
    for (const auto& term : termNodes) {
        root->addChild(term);
    }

    collapseIdenticalGates(root, maxFanIn);
    if (maxFanIn > 1) enforceMaxFanIn(root, maxFanIn);
    return root;
}

bool CircuitBuilder::isVariable(const std::string& token) {
    return !token.empty() && std::isalnum(static_cast<unsigned char>(token[0]));
}

bool CircuitBuilder::isNot(const std::string& token) {
    return token == "!" || token == "'";
}

bool CircuitBuilder::isBinaryOperator(const std::string& token) {
    return token == "&" || token == "|" || token == "@" || token == "^" || token == "=";
}

CircuitNodePtr CircuitBuilder::createGateForOperator(const std::string& operatorStr, const CircuitNodePtr& left, const CircuitNodePtr& right) {
    CircuitNodePtr gate = nullptr;

    if (operatorStr == "&") {
        gate = std::make_shared<CircuitNode>(NodeType::AND);
        gate->addChild(left);
        gate->addChild(right);
    } else if (operatorStr == "|") {
        gate = std::make_shared<CircuitNode>(NodeType::OR);
        gate->addChild(left);
        gate->addChild(right);
    } else if (operatorStr == "@") { // IMPLIES: A @ B = !A | B
        CircuitNodePtr notGate = std::make_shared<CircuitNode>(NodeType::NOT);
        notGate->addChild(left);
        gate = std::make_shared<CircuitNode>(NodeType::OR);
        gate->addChild(notGate);
        gate->addChild(right);
    } else if (operatorStr == "=") { // EQUIVALENCE (XNOR)
        gate = std::make_shared<CircuitNode>(NodeType::XNOR);
        gate->addChild(left);
        gate->addChild(right);
    } else if (operatorStr == "^") { // XOR
        gate = std::make_shared<CircuitNode>(NodeType::XOR);
        gate->addChild(left);
        gate->addChild(right);
    }

    return gate;
}

CircuitNodePtr CircuitBuilder::buildTermNode(const std::string& binary, const std::vector<std::string>& variables, bool isPOS) {
    std::vector<CircuitNodePtr> literals;

    for (size_t i = 0; i < binary.length() && i < variables.size(); i++) {
        char bit = binary[i];
        if (bit == '-')
            continue;

        CircuitNodePtr varNode = std::make_shared<CircuitNode>(variables[i]);
        bool needsNot = isPOS ? (bit == '1') : (bit == '0');

        if (needsNot) {
            CircuitNodePtr notGate = std::make_shared<CircuitNode>(NodeType::NOT);
            notGate->addChild(varNode);
            literals.push_back(notGate);
        } else {
            literals.push_back(varNode);
        }
    }

    if (literals.empty()) {
        return std::make_shared<CircuitNode>(isPOS ? "0" : "1");
    }

    if (literals.size() == 1) {
        return literals[0];
    }

    NodeType gateType = isPOS ? NodeType::OR : NodeType::AND;
    CircuitNodePtr gate = std::make_shared<CircuitNode>(gateType);
    for (const auto& literal : literals) {
        gate->addChild(literal);
    }

    return gate;
}

CircuitNodePtr CircuitBuilder::cloneNode(const CircuitNodePtr& node) {
    if (node == nullptr)
        return nullptr;

    CircuitNodePtr cloneNodePtr;
    if (node->isVariable()) {
        cloneNodePtr = std::make_shared<CircuitNode>(node->getValue());
    } else {
        cloneNodePtr = std::make_shared<CircuitNode>(node->getType());
    }

    for (const auto& child : node->getChildren()) {
        cloneNodePtr->addChild(cloneNode(child));
    }

    return cloneNodePtr;
}

void CircuitBuilder::collapseIdenticalGates(const CircuitNodePtr& node, int maxFanIn) {
    if (!node) return;

    for (const auto& child : node->getChildren()) {
        collapseIdenticalGates(child, maxFanIn);
    }

    if (node->isGate() && (node->getType() == NodeType::AND || node->getType() == NodeType::OR)) {
        std::vector<CircuitNodePtr> newChildren;
        const auto& originalChildren = node->getChildren();
        for (size_t idx = 0; idx < originalChildren.size(); idx++) {
            const auto& child = originalChildren[idx];
            if (child->isGate() && child->getType() == node->getType()) {
                size_t remaining = originalChildren.size() - 1 - idx;
                // If maxFanIn is 0, unlimited fan-in
                if (maxFanIn == 0 || newChildren.size() + child->getChildren().size() + remaining <= static_cast<size_t>(maxFanIn)) {
                    for (const auto& grandChild : child->getChildren()) {
                        newChildren.push_back(grandChild);
                    }
                    continue;
                }
            }
            newChildren.push_back(child);
        }
        node->clearChildren();
        for (const auto& child : newChildren) {
            node->addChild(child);
        }
    }
}

void CircuitBuilder::enforceMaxFanIn(const CircuitNodePtr& node, int maxFanIn) {
    if (!node || maxFanIn <= 1) return;

    // Recursively enforce for children
    for (const auto& child : node->getChildren()) {
        enforceMaxFanIn(child, maxFanIn);
    }

    if (node->isGate() && (node->getType() == NodeType::AND || node->getType() == NodeType::OR)) {
        while (node->getChildren().size() > static_cast<size_t>(maxFanIn)) {
            // Group the first 'maxFanIn' children into a new sub-gate
            std::vector<CircuitNodePtr> children = node->getChildren();
            CircuitNodePtr subGate = std::make_shared<CircuitNode>(node->getType());
            for (int i = 0; i < maxFanIn; i++) {
                subGate->addChild(children[i]);
            }
            
            // Rebuild current node's children: subGate + remaining children
            node->clearChildren();
            node->addChild(subGate);
            for (size_t i = maxFanIn; i < children.size(); i++) {
                node->addChild(children[i]);
            }
        }
    }
}


CircuitNodePtr CircuitBuilder::convertToNAND(const CircuitNodePtr& node) {
    if (!node) return nullptr;
    if (node->isVariable()) return cloneNode(node);

    std::vector<CircuitNodePtr> children;
    for (const auto& c : node->getChildren()) {
        children.push_back(convertToNAND(c));
    }

    auto makeNand = [](const std::vector<CircuitNodePtr>& ch) {
        auto n = std::make_shared<CircuitNode>(NodeType::NAND);
        for (const auto& c : ch) n->addChild(c);
        return n;
    };

    if (node->getType() == NodeType::NOT) {
        return makeNand(children);
    } else if (node->getType() == NodeType::AND) {
        return makeNand({ makeNand(children) });
    } else if (node->getType() == NodeType::OR) {
        std::vector<CircuitNodePtr> negatedChildren;
        for (const auto& c : children) negatedChildren.push_back(makeNand({c}));
        return makeNand(negatedChildren);
    }
    return makeNand(children);
}

CircuitNodePtr CircuitBuilder::convertToNOR(const CircuitNodePtr& node) {
    if (!node) return nullptr;
    if (node->isVariable()) return cloneNode(node);

    std::vector<CircuitNodePtr> children;
    for (const auto& c : node->getChildren()) {
        children.push_back(convertToNOR(c));
    }

    auto makeNor = [](const std::vector<CircuitNodePtr>& ch) {
        auto n = std::make_shared<CircuitNode>(NodeType::NOR);
        for (const auto& c : ch) n->addChild(c);
        return n;
    };

    if (node->getType() == NodeType::NOT) {
        return makeNor(children);
    } else if (node->getType() == NodeType::OR) {
        return makeNor({ makeNor(children) });
    } else if (node->getType() == NodeType::AND) {
        std::vector<CircuitNodePtr> negatedChildren;
        for (const auto& c : children) negatedChildren.push_back(makeNor({c}));
        return makeNor(negatedChildren);
    }
    return makeNor(children);
}

void CircuitBuilder::cancelDoubleNot(CircuitNodePtr& node) {
    if (!node) return;

    auto isNotEquivalent = [](const CircuitNodePtr& n) {
        return n && (n->getType() == NodeType::NOT ||
                     ((n->getType() == NodeType::NAND || n->getType() == NodeType::NOR) && n->getChildren().size() == 1));
    };

    while (isNotEquivalent(node)) {
        CircuitNodePtr child1 = node->getChildren()[0];
        if (isNotEquivalent(child1)) {
            node = child1->getChildren()[0];
        } else {
            break;
        }
    }

    if (node && !node->isVariable()) {
        std::vector<CircuitNodePtr> newChildren;
        for (auto child : node->getChildren()) {
            CircuitNodePtr modChild = child;
            cancelDoubleNot(modChild);
            newChildren.push_back(modChild);
        }
        node->clearChildren();
        for (const auto& child : newChildren) {
            node->addChild(child);
        }
    }
}

} // namespace com::mantiq::circuit
