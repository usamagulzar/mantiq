#pragma once
#include <string>
#include <vector>

namespace com::mantiq::circuit {

enum class NodeType {
    AND,
    OR,
    NOT,
    XOR,
    XNOR,
    NAND,
    NOR,
    VARIABLE
};

inline bool isGate(NodeType type) {
    return type == NodeType::AND || type == NodeType::OR || type == NodeType::NOT || type == NodeType::XOR || type == NodeType::XNOR || type == NodeType::NAND || type == NodeType::NOR;
}

inline bool evaluateNodeType(NodeType type, const std::vector<bool>& inputs) {
    if (type == NodeType::AND) {
        if (inputs.empty()) return false;
        for (bool b : inputs) if (!b) return false;
        return true;
    } else if (type == NodeType::OR) {
        for (bool b : inputs) if (b) return true;
        return false;
    } else if (type == NodeType::NOT) {
        if (inputs.empty()) return true;
        return !inputs[0];
    } else if (type == NodeType::XOR) {
        bool result = false;
        for (bool b : inputs) result ^= b;
        return result;
    } else if (type == NodeType::XNOR) {
        bool result = false;
        for (bool b : inputs) result ^= b;
        return !result;
    } else if (type == NodeType::NAND) {
        if (inputs.empty()) return true;
        for (bool b : inputs) if (!b) return true;
        return false;
    } else if (type == NodeType::NOR) {
        for (bool b : inputs) if (b) return false;
        return true;
    }
    return false;
}

inline std::string verilogGate(NodeType type) {
    if (type == NodeType::AND) return "and";
    if (type == NodeType::OR) return "or";
    if (type == NodeType::NOT) return "not";
    if (type == NodeType::XOR) return "xor";
    if (type == NodeType::XNOR) return "xnor";
    if (type == NodeType::NAND) return "nand";
    if (type == NodeType::NOR) return "nor";
    return "buf";
}

inline std::string verilogOperator(NodeType type) {
    if (type == NodeType::AND) return "&";
    if (type == NodeType::OR) return "|";
    if (type == NodeType::NOT) return "~";
    if (type == NodeType::XOR) return "^";
    if (type == NodeType::XNOR) return "~^";
    if (type == NodeType::NAND) return "~&";
    if (type == NodeType::NOR) return "~|";
    return "";
}

} // namespace com::mantiq::circuit
