#include "QuineMcCluskey.h"
#include <sstream>
#include <cmath>
#include <algorithm>
#include <map>

namespace com::mantiq::logic {

template<typename T>
static std::string formatList(const T& container) {
    std::stringstream ss;
    ss << "[";
    bool first = true;
    for (const auto& item : container) {
        if (!first) ss << ", ";
        ss << item;
        first = false;
    }
    ss << "]";
    return ss.str();
}

std::string QuineMcCluskey::Implicant::toString() const {
    std::stringstream ss;
    ss << binary << " " << formatList(minterms);
    return ss.str();
}

std::vector<std::string> QuineMcCluskey::minimize(int numVars, const std::vector<int>& minterms) {
    return minimize(numVars, minterms, {});
}

std::vector<std::string> QuineMcCluskey::minimize(int numVars, const std::vector<int>& minterms, const std::vector<int>& dontCares) {
    return minimizeWithDetails(numVars, minterms, dontCares).solution;
}

QuineMcCluskey::MinimizationResult QuineMcCluskey::minimizeWithDetails(int numVars, const std::vector<int>& minterms, const std::vector<int>& dontCares) {
    std::stringstream steps;
    steps << "=== Quine-McCluskey Minimization ===\n\n";

    if (minterms.empty()) {
        steps << "No minterms provided. Expression simplifies to 0 (or 1 for POS).\n";
        return MinimizationResult({}, {}, {}, {}, steps.str());
    }

    int maxTerms = static_cast<int>(std::pow(2, numVars));
    if (minterms.size() == static_cast<size_t>(maxTerms)) {
        steps << "All possible minterms exist. Expression simplifies to 1 (or 0 for POS).\n";
        std::string allDashes(numVars, '-');
        return MinimizationResult({ allDashes }, { allDashes }, { allDashes }, {{ allDashes }}, steps.str());
    }

    std::set<int> allTerms(minterms.begin(), minterms.end());
    allTerms.insert(dontCares.begin(), dontCares.end());

    steps << "1. Initial Setup\n";
    steps << "   Variables: " << numVars << "\n";
    steps << "   Minterms to cover: " << formatList(minterms) << "\n";
    if (!dontCares.empty()) {
        steps << "   Don't Cares (can be used for grouping): " << formatList(dontCares) << "\n";
    }
    steps << "\n";

    std::vector<Implicant> terms;
    steps << "   Initial Term Binary Representations:\n";
    std::set<int> dontCaresSet(dontCares.begin(), dontCares.end());
    for (int m : allTerms) {
        std::string bin = toBinary(m, numVars);
        terms.push_back(Implicant(bin, { m }));
        steps << "     m" << m << " = " << bin;
        if (dontCaresSet.count(m)) {
            steps << " (d)";
        }
        steps << "\n";
    }
    steps << "\n";

    steps << "2. Finding Prime Implicants (Merging adjacent terms)\n";
    std::string mergeSteps = "";
    std::vector<Implicant> primeImplicants = findPrimeImplicants(terms, mergeSteps);
    steps << mergeSteps;

    std::set<int> mintermSet(minterms.begin(), minterms.end());
    std::vector<Implicant> validPrimeImplicants;
    for (const auto& p : primeImplicants) {
        bool coversMinterm = false;
        for (int m : p.minterms) {
            if (mintermSet.count(m)) {
                coversMinterm = true;
                break;
            }
        }
        if (coversMinterm) {
            validPrimeImplicants.push_back(p);
        }
    }

    steps << "\n3. Filtering & Prime Implicant Dominance\n";
    std::vector<Implicant> nonDominatedPrimes;
    for (size_t i = 0; i < validPrimeImplicants.size(); i++) {
        bool isDominated = false;
        for (size_t j = 0; j < validPrimeImplicants.size(); j++) {
            if (i != j && isSubsumedBy(validPrimeImplicants[i].binary, validPrimeImplicants[j].binary)) {
                isDominated = true;
                steps << "   -> " << validPrimeImplicants[i].binary << " is dominated by " << validPrimeImplicants[j].binary
                      << " (Discarded)\n";
                break;
            }
        }
        if (!isDominated) {
            nonDominatedPrimes.push_back(validPrimeImplicants[i]);
        }
    }

    steps << "\n   Final Valid Prime Implicants:\n";
    std::vector<std::string> allPrimes;
    for (const auto& p : nonDominatedPrimes) {
        allPrimes.push_back(p.binary);
        steps << "     " << p.binary << " covers " << formatList(p.minterms) << "\n";
    }
    steps << "\n";

    steps << "4. Prime Implicant Chart (Coverage Phase)\n";
    std::vector<std::string> essentials;
    std::vector<std::vector<std::string>> allSols;
    std::string coverageSteps = "";
    std::vector<std::string> solution = findMinimalCoverWithEssentials(nonDominatedPrimes, mintermSet, essentials, allSols, coverageSteps);
    steps << coverageSteps;

    steps << "\n=== Final Minimization Result ===\n";
    steps << "Minimized Terms: " << formatList(solution) << "\n";

    return MinimizationResult(allPrimes, essentials, solution, allSols, steps.str());
}

bool QuineMcCluskey::isSubsumedBy(const std::string& a, const std::string& b) {
    if (a.length() != b.length())
        return false;
    int aDashes = 0, bDashes = 0;
    for (size_t i = 0; i < a.length(); i++) {
        char ca = a[i];
        char cb = b[i];
        if (ca == '-') aDashes++;
        if (cb == '-') bDashes++;
        if (ca != '-' && cb != '-' && ca != cb)
            return false;
        if (ca == '-' && cb != '-')
            return false;
    }
    return bDashes > aDashes;
}

std::vector<QuineMcCluskey::Implicant> QuineMcCluskey::findPrimeImplicants(const std::vector<Implicant>& initialTerms, std::string& steps) {
    std::stringstream ss;
    std::vector<Implicant> primeImplicants;
    std::vector<Implicant> currentLevel = initialTerms;
    int pass = 1;

    while (!currentLevel.empty()) {
        ss << "\n   --- Pass " << pass << " (Grouping size " << static_cast<int>(std::pow(2, pass)) << ") ---\n";
        int mergeCount = 0;

        std::set<std::string> mergedBinaries;
        std::vector<Implicant> nextLevel;
        std::vector<bool> wasMerged(currentLevel.size(), false);

        int numVars = currentLevel[0].binary.length();
        std::vector<std::vector<size_t>> buckets(numVars + 1);
        for (size_t i = 0; i < currentLevel.size(); i++) {
            buckets[currentLevel[i].popcount].push_back(i);
        }

        for (int k = 0; k < numVars; k++) {
            for (size_t iIdx : buckets[k]) {
                for (size_t jIdx : buckets[k + 1]) {
                    std::string merged = tryMerge(currentLevel[iIdx].binary, currentLevel[jIdx].binary);
                    if (!merged.empty()) {
                        wasMerged[iIdx] = true;
                        wasMerged[jIdx] = true;
                        if (mergedBinaries.find(merged) == mergedBinaries.end()) {
                            mergedBinaries.insert(merged);

                            std::set<int> combinedMinterms = currentLevel[iIdx].minterms;
                            combinedMinterms.insert(currentLevel[jIdx].minterms.begin(), currentLevel[jIdx].minterms.end());

                            nextLevel.push_back(Implicant(merged, combinedMinterms));
                            ss << "     Merged: " << currentLevel[iIdx].binary << " + "
                               << currentLevel[jIdx].binary << " -> " << merged << "\n";
                            mergeCount++;
                        }
                    }
                }
            }
        }

        for (size_t i = 0; i < currentLevel.size(); i++) {
            if (!wasMerged[i]) {
                std::string binaryToCheck = currentLevel[i].binary;
                bool alreadyExists = false;
                for (const auto& p : primeImplicants) {
                    if (p.binary == binaryToCheck) {
                        alreadyExists = true;
                        break;
                    }
                }
                if (!alreadyExists) {
                    primeImplicants.push_back(currentLevel[i]);
                    ss << "     * PI: " << currentLevel[i].binary << " covers " << formatList(currentLevel[i].minterms) << "\n";
                }
            }
        }

        if (mergeCount == 0) {
            ss << "     No more merges possible.\n";
        }
        currentLevel = nextLevel;
        pass++;
    }

    steps = ss.str();
    return primeImplicants;
}

// Branch-and-bound over "include candidate / skip candidate", same as
// before, but with two changes that only ever remove work, never change
// which covers get found:
//
//  1. `minSize` is threaded through by reference and updated in place the
//     moment a smaller complete cover is found, instead of being
//     recomputed from scratch by scanning the entire `allCovers` list on
//     EVERY recursive call (which used to make each node's overhead grow
//     with the number of covers already found - quadratic-ish blowup on
//     top of the already-exponential search).
//
//  2. Before recursing further, we compute an admissible lower bound on
//     how many MORE candidates this branch would need at minimum: the
//     best any single remaining candidate can do is cover
//     `maxSingleCoverage` of the still-uncovered minterms, so at least
//     ceil(uncovered / maxSingleCoverage) more picks are unavoidable from
//     here. If even that best case can't beat (or tie) the best complete
//     cover found so far, this whole branch is pruned. This is the exact
//     generalization of the original "at least 1 more pick is needed"
//     assumption the old code implicitly used (equivalent to it when
//     maxSingleCoverage == 1) - it never discards a cover that could end
//     up tied-or-better, so the final `allCovers` set (and therefore every
//     solution ExpressionProcessor/QuineMcCluskey ultimately reports) is
//     unchanged. It just stops walking down subtrees that are
//     mathematically guaranteed to be worse, which is what actually
//     explodes on adversarial inputs (e.g. an n-variable XOR/XNOR pattern,
//     which has no essential prime implicants and many equally-good,
//     mutually non-dominated ones for the essential-PI pass above to
//     shortcut).
static void findCovers(
    size_t startIndex,
    std::vector<std::string>& currentCover,
    std::set<int>& uncovered,
    const std::vector<std::string>& candidates,
    const std::map<std::string, std::set<int>>& actualCoverage,
    std::vector<std::vector<std::string>>& allCovers,
    size_t& minSize
) {
    if (uncovered.empty()) {
        allCovers.push_back(currentCover);
        if (currentCover.size() < minSize) minSize = currentCover.size();
        return;
    }
    if (startIndex >= candidates.size()) {
        return;
    }

    size_t maxSingleCoverage = 0;
    for (size_t k = startIndex; k < candidates.size(); k++) {
        auto covIt = actualCoverage.find(candidates[k]);
        if (covIt == actualCoverage.end()) continue;
        size_t cnt = 0;
        for (int m : covIt->second) {
            if (uncovered.count(m)) cnt++;
        }
        if (cnt > maxSingleCoverage) maxSingleCoverage = cnt;
    }
    if (maxSingleCoverage == 0) {
        return; // none of the remaining candidates can cover anything left - dead end
    }
    size_t lowerBoundAdds = (uncovered.size() + maxSingleCoverage - 1) / maxSingleCoverage;
    if (currentCover.size() + lowerBoundAdds > minSize) {
        return; // even the best case from here can't tie the best cover found so far
    }

    std::string candidate = candidates[startIndex];
    std::set<int> coveredByThis;
    auto it = actualCoverage.find(candidate);
    if (it != actualCoverage.end()) {
        for (int m : it->second) {
            if (uncovered.count(m)) {
                coveredByThis.insert(m);
            }
        }
    }

    if (!coveredByThis.empty()) {
        currentCover.push_back(candidate);
        for (int m : coveredByThis) uncovered.erase(m);

        findCovers(startIndex + 1, currentCover, uncovered, candidates, actualCoverage, allCovers, minSize);

        for (int m : coveredByThis) uncovered.insert(m);
        currentCover.pop_back();
    }

    findCovers(startIndex + 1, currentCover, uncovered, candidates, actualCoverage, allCovers, minSize);
}

std::vector<std::string> QuineMcCluskey::findMinimalCoverWithEssentials(
    std::vector<Implicant>& primeImplicants,
    const std::set<int>& mintermsToCover,
    std::vector<std::string>& outEssentials,
    std::vector<std::vector<std::string>>& outAllSolutions,
    std::string& steps
) {
    std::stringstream ss;
    std::vector<std::string> solution;
    std::set<int> uncovered = mintermsToCover;

    for (auto& p : primeImplicants) {
        p.isEssential = false;
    }

    std::map<std::string, std::set<int>> actualCoverage;
    for (const auto& p : primeImplicants) {
        std::set<int> covered;
        for (int m : p.minterms) {
            if (mintermsToCover.count(m)) {
                covered.insert(m);
            }
        }
        actualCoverage[p.binary] = covered;
    }

    ss << "   Finding Essential Prime Implicants:\n";
    bool foundEssential = false;

    for (int m : mintermsToCover) {
        std::vector<std::string> covering;
        for (const auto& p : primeImplicants) {
            if (actualCoverage[p.binary].count(m)) {
                covering.push_back(p.binary);
            }
        }

        if (covering.size() == 1) {
            for (auto& p : primeImplicants) {
                if (p.binary == covering[0] && !p.isEssential) {
                    p.isEssential = true;
                    solution.push_back(p.binary);
                    outEssentials.push_back(p.binary);
                    for (int covM : actualCoverage[p.binary]) {
                        uncovered.erase(covM);
                    }
                    ss << "     -> '" << p.binary << "' is essential (only one covering m" << m << ")\n";
                    foundEssential = true;
                    break;
                }
            }
        }
    }

    if (!foundEssential) {
        ss << "     No essential prime implicants found.\n";
    }

    std::vector<std::string> candidates;
    for (const auto& p : primeImplicants) {
        if (!p.isEssential) {
            candidates.push_back(p.binary);
        }
    }

    std::vector<std::vector<std::string>> allCovers;
    std::vector<std::string> currentCover = solution;

    size_t minSize = 999999;
    findCovers(0, currentCover, uncovered, candidates, actualCoverage, allCovers, minSize);

    outAllSolutions.clear();
    for (const auto& cov : allCovers) {
        if (cov.size() == minSize) {
            auto sorted = cov;
            std::sort(sorted.begin(), sorted.end());
            if (std::find(outAllSolutions.begin(), outAllSolutions.end(), sorted) == outAllSolutions.end()) {
                outAllSolutions.push_back(sorted);
            }
        }
    }

    if (outAllSolutions.empty()) {
        outAllSolutions.push_back(solution);
    }

    solution = outAllSolutions[0];

    ss << "\n   Solutions found: " << outAllSolutions.size() << "\n";
    for (size_t i = 0; i < outAllSolutions.size(); i++) {
        ss << "     Solution " << (i + 1) << ": " << formatList(outAllSolutions[i]) << "\n";
    }

    steps = ss.str();
    return solution;
}

std::string QuineMcCluskey::toBinary(int n, int numVars) {
    std::string result = "";
    for (int i = numVars - 1; i >= 0; i--) {
        result += ((n >> i) & 1) ? '1' : '0';
    }
    return result;
}

std::string QuineMcCluskey::tryMerge(const std::string& a, const std::string& b) {
    if (a.length() != b.length()) return "";

    int diff = 0;
    std::string result = a;

    for (size_t i = 0; i < a.length(); i++) {
        if (a[i] != b[i]) {
            if (++diff > 1) return "";
            result[i] = '-';
        }
    }
    return diff == 1 ? result : "";
}

} // namespace com::mantiq::logic
