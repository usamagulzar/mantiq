const fs = require('fs');
let content = fs.readFileSync('wasm/src/circuit/CircuitBuilder.cpp', 'utf-8');

const funcs = 

CircuitNodePtr CircuitBuilder::convertToNAND(const CircuitNodePtr& node) {
    if (!node) return nullptr;
    if (node->isVariable() || node->getType() == NodeType::CONSTANT) return cloneNode(node);

    std::vector<CircuitNodePtr> children;
    for (const auto& c : node->getChildren()) {
        children.push_back(convertToNAND(c));
    }

    auto makeNand = [](const std::vector<CircuitNodePtr>& ch) {
        auto n = std::make_shared<CircuitNode>(NodeType::NAND);
        for (const auto& c : ch) n->addChild(c);
        return n;
    };

    if (node->getType() == NodeType::NOT) {
        return makeNand(children);
    } else if (node->getType() == NodeType::AND) {
        return makeNand({ makeNand(children) });
    } else if (node->getType() == NodeType::OR) {
        std::vector<CircuitNodePtr> negatedChildren;
        for (const auto& c : children) negatedChildren.push_back(makeNand({c}));
        return makeNand(negatedChildren);
    }
    return makeNand(children); // Fallback
}

CircuitNodePtr CircuitBuilder::convertToNOR(const CircuitNodePtr& node) {
    if (!node) return nullptr;
    if (node->isVariable() || node->getType() == NodeType::CONSTANT) return cloneNode(node);

    std::vector<CircuitNodePtr> children;
    for (const auto& c : node->getChildren()) {
        children.push_back(convertToNOR(c));
    }

    auto makeNor = [](const std::vector<CircuitNodePtr>& ch) {
        auto n = std::make_shared<CircuitNode>(NodeType::NOR);
        for (const auto& c : ch) n->addChild(c);
        return n;
    };

    if (node->getType() == NodeType::NOT) {
        return makeNor(children);
    } else if (node->getType() == NodeType::OR) {
        return makeNor({ makeNor(children) });
    } else if (node->getType() == NodeType::AND) {
        std::vector<CircuitNodePtr> negatedChildren;
        for (const auto& c : children) negatedChildren.push_back(makeNor({c}));
        return makeNor(negatedChildren);
    }
    return makeNor(children); // Fallback
}

void CircuitBuilder::cancelDoubleNot(CircuitNodePtr& node) {
    if (!node) return;

    // A NOT-equivalent is a NAND or NOR with exactly 1 child
    auto isNotEquivalent = [](const CircuitNodePtr& n) {
        return n && (n->getType() == NodeType::NOT ||
                     ((n->getType() == NodeType::NAND || n->getType() == NodeType::NOR) && n->getChildren().size() == 1));
    };

    // Keep resolving double NOTs at the current root if possible
    while (isNotEquivalent(node)) {
        CircuitNodePtr child1 = node->getChildren()[0];
        if (isNotEquivalent(child1)) {
            // Cancel out: replace node with child1's child
            node = child1->getChildren()[0];
        } else {
            break;
        }
    }

    // Now safely recurse for children
    if (node && !node->isVariable() && node->getType() != NodeType::CONSTANT) {
        std::vector<CircuitNodePtr> newChildren;
        for (auto child : node->getChildren()) {
            CircuitNodePtr modChild = child;
            cancelDoubleNot(modChild);
            newChildren.push_back(modChild);
        }
        node->clearChildren();
        for (const auto& child : newChildren) {
            node->addChild(child);
        }
    }
}
;
content += funcs;
fs.writeFileSync('wasm/src/circuit/CircuitBuilder.cpp', content);
