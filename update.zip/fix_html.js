const fs = require('fs');
let content = fs.readFileSync('app.html', 'utf-8');

const faninRegex = /<select class="fanin-select" title="Max Fan-In Allowed">[\s\S]*?<\/select>/g;

const replacement = '<select class="impl-select" title="Gate Implementation">\n' +
'                                    <option value="0" selected>Implementation: Default</option>\n' +
'                                    <option value="1">Implementation: NAND-NAND</option>\n' +
'                                    <option value="2">Implementation: NOR-NOR</option>\n' +
'                                </select>\n' +
'                                <select class="fanin-select" title="Max Fan-In Allowed">\n' +
'                                    <option value="2">Max Fan-In: 2 Inputs</option>\n' +
'                                    <option value="3">Max Fan-In: 3 Inputs</option>\n' +
'                                    <option value="4" selected>Max Fan-In: 4 Inputs</option>\n' +
'                                </select>';

content = content.replace(faninRegex, replacement);
fs.writeFileSync('app.html', content);
