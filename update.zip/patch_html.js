const fs = require('fs');
let html = fs.readFileSync('app.html', 'utf-8');

// 1. Add ast-prover.js to scripts
html = html.replace('<script src="js/app-core.js?v=2.2.11"></script>', '<script src="js/ast-prover.js?v=2.2.12"></script>\n    <script src="js/app-core.js?v=2.2.12"></script>');
// Bump other js versions for cache
html = html.replace(/\?v=2\.2\.11/g, '?v=2.2.12');

// 2. Add 'Minimal IC' and 'IC Family' to dialog
const dialogOptions = `
          <option value="0" selected>Default (AND / OR / NOT)</option>
          <option value="1">NAND-NAND</option>
          <option value="2">NOR-NOR</option>
          <option value="3">Minimal IC (AST Prover)</option>
        </select>
      </div>
      <div class="input-group" id="dialog-ic-family-group" style="display: none;">
        <label style="font-size: 13px; font-weight: 500; color: var(--text-secondary); margin-bottom: 6px; display: block;">IC Family</label>
        <select class="family-select" id="dialog-family-select" style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid var(--border-color); background: var(--input-bg); color: var(--text-primary); outline: none; cursor: pointer;">
          <option value="TTL" selected>TTL (74xx)</option>
          <option value="LS-TTL">LS-TTL (74LSxx)</option>
          <option value="CMOS">CMOS (CD4000)</option>
        </select>
      </div>
`;
html = html.replace(/<option value="0" selected>Default \(AND \/ OR \/ NOT\)<\/option>[\s\S]*?<\/select>\s*<\/div>/, dialogOptions.trim());

// 3. Add eye icon and IC badge to Circuit and Sim panel headers
const extraButtons = `
  <div class="ic-badge" style="display:none; font-size: 12px; font-weight:600; color:var(--accent-color); background: var(--glass-bg, rgba(255,255,255,0.06)); padding: 4px 8px; border-radius: 12px; margin-right: 8px; border: 1px solid var(--border-color); white-space:nowrap; align-items:center;">🔌 <span class="ic-count-num">0</span> ICs</div>
  <button class="circuit-settings-btn toggle-ic-labels-btn" title="Toggle IC Labels" style="display:none; margin-right: 8px;" aria-label="Toggle Labels">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
  </button>
  <button class="circuit-settings-btn"`;
html = html.replace(/<button class="circuit-settings-btn"/g, extraButtons.trim());

fs.writeFileSync('app.html', html);
console.log('Patched app.html');
