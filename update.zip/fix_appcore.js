const fs = require('fs');
let content = fs.readFileSync('js/app-core.js', 'utf-8');
const implScript = "\ndocument.querySelectorAll('.impl-select').forEach(select => {\n" +
"    select.addEventListener('change', (e) => {\n" +
"        const impl = parseInt(e.target.value, 10);\n" +
"        document.querySelectorAll('.impl-select').forEach(s => {\n" +
"            if (s !== e.target) s.value = e.target.value;\n" +
"        });\n" +
"        if (wasmReady) {\n" +
"            Module.ccall('mantiq_setImplementation', null, ['number'], [impl]);\n" +
"        }\n" +
"    });\n" +
"});\n";
content += implScript;
fs.writeFileSync('js/app-core.js', content);
