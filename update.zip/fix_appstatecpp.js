const fs = require('fs');
let content = fs.readFileSync('wasm/src/app/AppState.cpp', 'utf-8');

// We need to apply convertToNAND or convertToNOR to originalCircuit and simplifiedCircuit if implementationMode != 0
content = content.replace(
    'originalCircuit = circuit::CircuitBuilder::fromPostfix(processResult.getOriginalPostfix(), maxFanIn);',
    'originalCircuit = circuit::CircuitBuilder::fromPostfix(processResult.getOriginalPostfix(), maxFanIn);\n    if (implementationMode == 1) {\n        originalCircuit = circuit::CircuitBuilder::convertToNAND(originalCircuit);\n        circuit::CircuitBuilder::cancelDoubleNot(originalCircuit);\n    } else if (implementationMode == 2) {\n        originalCircuit = circuit::CircuitBuilder::convertToNOR(originalCircuit);\n        circuit::CircuitBuilder::cancelDoubleNot(originalCircuit);\n    }'
);

content = content.replace(
    'simplifiedCircuit = circuit::CircuitBuilder::fromSimplifiedTerms(\n        terms, processResult.getVariables(), !sop, maxFanIn);',
    'simplifiedCircuit = circuit::CircuitBuilder::fromSimplifiedTerms(\n        terms, processResult.getVariables(), !sop, maxFanIn);\n    if (implementationMode == 1) {\n        simplifiedCircuit = circuit::CircuitBuilder::convertToNAND(simplifiedCircuit);\n        circuit::CircuitBuilder::cancelDoubleNot(simplifiedCircuit);\n    } else if (implementationMode == 2) {\n        simplifiedCircuit = circuit::CircuitBuilder::convertToNOR(simplifiedCircuit);\n        circuit::CircuitBuilder::cancelDoubleNot(simplifiedCircuit);\n    }'
);

content = content.replace(
    'simplifiedCircuit = circuit::CircuitBuilder::fromPostfix(reparse.getOriginalPostfix(), maxFanIn);\n            }',
    'simplifiedCircuit = circuit::CircuitBuilder::fromPostfix(reparse.getOriginalPostfix(), maxFanIn);\n                if (implementationMode == 1) {\n                    simplifiedCircuit = circuit::CircuitBuilder::convertToNAND(simplifiedCircuit);\n                    circuit::CircuitBuilder::cancelDoubleNot(simplifiedCircuit);\n                } else if (implementationMode == 2) {\n                    simplifiedCircuit = circuit::CircuitBuilder::convertToNOR(simplifiedCircuit);\n                    circuit::CircuitBuilder::cancelDoubleNot(simplifiedCircuit);\n                }\n            }'
);

fs.writeFileSync('wasm/src/app/AppState.cpp', content);
