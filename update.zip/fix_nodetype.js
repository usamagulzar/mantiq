const fs = require('fs');
let content = fs.readFileSync('wasm/src/circuit/NodeType.h', 'utf-8');
content = content.replace('XOR,\n    XNOR,\n    VARIABLE', 'XOR,\n    XNOR,\n    NAND,\n    NOR,\n    VARIABLE');
content = content.replace('type == NodeType::XNOR;', 'type == NodeType::XNOR || type == NodeType::NAND || type == NodeType::NOR;');
content = content.replace('return !result;\n    }\n    return false;', 'return !result;\n    } else if (type == NodeType::NAND) {\n        if (inputs.empty()) return true;\n        for (bool b : inputs) if (!b) return true;\n        return false;\n    } else if (type == NodeType::NOR) {\n        for (bool b : inputs) if (b) return false;\n        return true;\n    }\n    return false;');
content = content.replace('if (type == NodeType::XNOR) return "xnor";', 'if (type == NodeType::XNOR) return "xnor";\n    if (type == NodeType::NAND) return "nand";\n    if (type == NodeType::NOR) return "nor";');
content = content.replace('if (type == NodeType::XNOR) return "~^";', 'if (type == NodeType::XNOR) return "~^";\n    if (type == NodeType::NAND) return "~&";\n    if (type == NodeType::NOR) return "~|";');
fs.writeFileSync('wasm/src/circuit/NodeType.h', content);
